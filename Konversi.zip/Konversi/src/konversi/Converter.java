/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package konversi;

/**
 *
 * @author OnO
 */

// Converter.java
public class Converter {
    private final UnitConverter[][] converters;

    public Converter() {

        converters = new UnitConverter[8][8];

    converters[0][1] = new KilometerToMeter();
    converters[1][0] = new MeterToKilometer();
    converters[0][2] = new KilometerToCentimeter();
    converters[2][0] = new CentimeterToKilometer();
    converters[0][3] = new KilometerToMillimeter();
    converters[3][0] = new MillimeterToKilometer();
    converters[0][4] = new KilometerToMil();
    converters[4][0] = new MilToKilometer();
    converters[0][5] = new KilometerToYard();
    converters[5][0] = new YardToKilometer();
    converters[0][6] = new KilometerToFeet();
    converters[6][0] = new FeetToKilometer();
    converters[0][7] = new KilometerToInch();
    converters[7][0] = new InchToKilometer();

    // Tambahkan konversi dari Meter
    converters[1][2] = new MeterToCentimeter();
    converters[2][1] = new CentimeterToMeter();
    converters[1][3] = new MeterToMillimeter();
    converters[3][1] = new MillimeterToMeter();
    converters[1][4] = new MeterToMil();
    converters[4][1] = new MilToMeter();
    converters[1][5] = new MeterToYard();
    converters[5][1] = new YardToMeter();
    converters[1][6] = new MeterToFeet();
    converters[6][1] = new FeetToMeter();
    converters[1][7] = new MeterToInch();
    converters[7][1] = new InchToMeter();

    // Tambahkan konversi dari Sentimeter
    converters[0][2] = new KilometerToCentimeter();
    converters[2][0] = new CentimeterToKilometer();
    converters[1][2] = new MeterToCentimeter();
    converters[2][1] = new CentimeterToMeter();
    converters[3][2] = new MillimeterToCentimeter();
    converters[2][3] = new CentimeterToMillimeter();
    converters[4][2] = new MilToCentimeter();
    converters[2][4] = new CentimeterToMil();
    converters[5][2] = new YardToCentimeter();
    converters[2][5] = new CentimeterToYard();
    converters[6][2] = new FeetToCentimeter();
    converters[2][6] = new CentimeterToFeet();
    converters[7][2] = new InchToCentimeter();
    converters[2][7] = new CentimeterToInch();

    // Tambahkan konversi dari Millimeter
    converters[0][3] = new KilometerToMillimeter();
    converters[3][0] = new MillimeterToKilometer();
    converters[1][3] = new MeterToMillimeter();
    converters[3][1] = new MillimeterToMeter();
    converters[2][3] = new CentimeterToMillimeter();
    converters[3][2] = new MillimeterToCentimeter();
    converters[4][3] = new MilToMillimeter();
    converters[3][4] = new MillimeterToMil();
    converters[5][3] = new YardToMillimeter();
    converters[3][5] = new MillimeterToYard();
    converters[6][3] = new FeetToMillimeter();
    converters[3][6] = new MillimeterToFeet();
    converters[7][3] = new InchToMillimeter();
    converters[3][7] = new MillimeterToInch();
    // ...

    // Tambahkan konversi dari Mil
    converters[0][4] = new KilometerToMil();
    converters[4][0] = new MilToKilometer();
    converters[1][4] = new MeterToMil();
    converters[4][1] = new MilToMeter();
    converters[2][4] = new CentimeterToMil();
    converters[4][2] = new MilToCentimeter();
    converters[3][4] = new MillimeterToMil();
    converters[4][3] = new MilToMillimeter();
    converters[5][4] = new YardToMil();
    converters[4][5] = new MilToYard();
    converters[6][4] = new FeetToMil();
    converters[4][6] = new MilToFeet();
    converters[7][4] = new InchToMil();
    converters[4][7] = new MilToInch();
    // ...

    // Tambahkan konversi dari Yard
    converters[0][5] = new KilometerToYard();
    converters[5][0] = new YardToKilometer();
    converters[1][5] = new MeterToYard();
    converters[5][1] = new YardToMeter();
    converters[2][5] = new CentimeterToYard();
    converters[5][2] = new YardToCentimeter();
    converters[3][5] = new MillimeterToYard();
    converters[5][3] = new YardToMillimeter();
    converters[4][5] = new MilToYard();
    converters[5][4] = new YardToMil();
    converters[6][5] = new FeetToYard();
    converters[5][6] = new YardToFeet();
    converters[7][5] = new InchToYard();
    converters[5][7] = new YardToInch();
    // ... 

    // Tambahkan konversi dari Feet
    converters[0][6] = new KilometerToFeet();
    converters[6][0] = new FeetToKilometer();
    converters[1][6] = new MeterToFeet();
    converters[6][1] = new FeetToMeter();
    converters[2][6] = new CentimeterToFeet();
    converters[6][2] = new FeetToCentimeter();
    converters[3][6] = new MillimeterToFeet();
    converters[6][3] = new FeetToMillimeter();
    converters[4][6] = new MilToFeet();
    converters[6][4] = new FeetToMil();
    converters[5][6] = new YardToFeet();
    converters[6][5] = new FeetToYard();
    converters[7][6] = new InchToFeet();
    converters[6][7] = new FeetToInch();
    // ... 
    
    // Tambahkan konversi dari Inch
    converters[0][7] = new KilometerToInch();
    converters[7][0] = new InchToKilometer();
    converters[1][7] = new MeterToInch();
    converters[7][1] = new InchToMeter();
    converters[2][7] = new CentimeterToInch();
    converters[7][2] = new InchToCentimeter();
    converters[3][7] = new MillimeterToInch();
    converters[7][3] = new InchToMillimeter();
    converters[4][7] = new MilToInch();
    converters[7][4] = new InchToMil();
    converters[5][7] = new YardToInch();
    converters[7][5] = new InchToYard();
    converters[6][7] = new FeetToInch();
    converters[7][6] = new InchToFeet();
    // ... 
}

    public double convert(double input, int inputIndex, int outputIndex) {
        if (inputIndex < 0 || inputIndex >= converters.length ||
            outputIndex < 0 || outputIndex >= converters[0].length ||
            converters[inputIndex][outputIndex] == null) {
   
            return input;
        }

        return converters[inputIndex][outputIndex].convert(input);
    }


    // KILOMETER
    private static class KilometerToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1000;
        }
    }

    private static class KilometerToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 100000;
        }
    }

    private static class KilometerToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1000000;
        }
    }

    private static class KilometerToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 1.609344;
        }
    }

    private static class KilometerToYard implements UnitConverter {
        @Override
        public double convert(double input) {
           return input * 1093.6133;
        }
    }

    private static class KilometerToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 3280.84;
        }
    }

    private static class KilometerToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 39370.1;
        }
    }

    // METER

    private static class MeterToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 1000;
        }
    }
    private static class MeterToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 100;
        }
    }
    private static class MeterToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1000;
        }
    }
    private static class MeterToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 0.000621371;
        }
    }
    private static class MeterToYard implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1.09361;
        }
    }
    private static class MeterToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 3.28084;
        }
    }
    private static class MeterToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 39.3701;
        }
    }
    
    //SENTIMETER
    private static class CentimeterToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 100000;
        }
    }
    private static class CentimeterToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 100;
        }
    }
    private static class CentimeterToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 10;
        }
    }
    private static class CentimeterToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input;
        }
    }
    private static class CentimeterToYard implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 91.44;
        }
    }
    private static class CentimeterToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 30.48;
        }
    }
    private static class CentimeterToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 2.54;
        }
    }
    
    //MILIMETER
    private static class MillimeterToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 1000000;
        }
    }
    private static class MillimeterToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 1000;
        }
    }
    private static class MillimeterToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 10;
        }
    }
    private static class MillimeterToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 25400;
        }
    }
    private static class MillimeterToYard implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 914.4;
        }
    }
    private static class MillimeterToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 304.8;
        }
    }
    private static class MillimeterToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 25.4;
        }
    }
    
    //MIL
    private static class MilToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1.609344;
        }
    }
    private static class MilToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1609.344;
        }
    }
    private static class MilToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 160934.4;
        }
    }
    private static class MilToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1609344;
        }
    }
    private static class MilToYard implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 0.9144;
        }
    }
    private static class MilToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 0.3048;
        }
    }
    private static class MilToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 0.0254;
        }
    }
    
    //YARD
    private static class YardToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 0.0009144;
        }
    }
    private static class YardToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 0.9144;
        }
    }
    private static class YardToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 91.44;
        }
    }
    private static class YardToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 914.4;
        }
    }
    private static class YardToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 1.09361;
        }
    }
    private static class YardToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 3;
        }
    }
    private static class YardToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 36;
        }
    }
    
    //FEET
    private static class FeetToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 3280.84;
        }
    }
    private static class FeetToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 3.28084;
        }
    }
    private static class FeetToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 30.48;
        }
    }
    private static class FeetToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 304.8;
        }
    }
    private static class FeetToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 3.048e-7;
        }
    }
    private static class FeetToYard implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 3;
        }
    }
    private static class FeetToInch implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 12;
        }
    }
    
    //INCI
    private static class InchToKilometer implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 39370.079;
        }
    }
    private static class InchToMeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 39.37;
        }
    }
    private static class InchToCentimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 2.54;
        }
    }
    private static class InchToMillimeter implements UnitConverter {
        @Override
        public double convert(double input) {
            return input * 25.4;
        }
    }
    private static class InchToMil implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 10000;
        }
    }
    private static class InchToFeet implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 12;
        }
    }
    private static class InchToYard implements UnitConverter {
        @Override
        public double convert(double input) {
            return input / 36;
        }
    }

}

